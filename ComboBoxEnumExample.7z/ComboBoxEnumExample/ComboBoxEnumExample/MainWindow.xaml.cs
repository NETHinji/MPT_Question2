﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static ComboBoxEnumExample.Employee;

namespace ComboBoxEnumExample
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            
        }
        public string constr = @"data source = ndamssql\sqlilearn; user id=sqluser; password=sqluser;initial catalog =Training_19Sep18_Pune";
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
          

            comboBoxCities.Items.Clear();
            foreach (var item in Enum.GetValues(typeof(Names)))
            {
                comboBoxCities.Items.Add(item);
            }
          
        }

        private void comboBoxCities_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            int value = (int)comboBoxCities.SelectedValue;
            SqlConnection con = new SqlConnection(constr);
            DataTable dt = new DataTable();
            SqlCommand com = new SqlCommand("Poonam_GetStudentDetails", con);
            com.Parameters.AddWithValue("@pid", value);
            com.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com.ExecuteReader();
            if (dr.HasRows)
            {
                dt.Load(dr);
                dataGridDisplay.ItemsSource = dt.DefaultView;
            }
            else
                MessageBox.Show("no values found");

            con.Close();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            
           
        }

        private void comboBoxCities_DropDownOpened(object sender, EventArgs e)
        {


        }
    }
}

