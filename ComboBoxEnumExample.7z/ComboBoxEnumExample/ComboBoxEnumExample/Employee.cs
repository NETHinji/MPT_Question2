﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComboBoxEnumExample
{
  public  class Employee
    {

        public int empid { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }

      public  enum Names
        {
          Poonam = 1,
          Pushpa = 2,
          Rushikesh = 3,

        };

    }
}
