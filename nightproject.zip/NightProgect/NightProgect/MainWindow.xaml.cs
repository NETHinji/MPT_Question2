﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace NightProgect
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void win1_Loaded(object sender, RoutedEventArgs e)
        {
            VaibhavInfoEntities vb = new VaibhavInfoEntities();
            StudentInfo sf = new StudentInfo();

            DbSet<StudentInfo> obj = vb.StudentInfoes;
            //int a = int.Parse(cmb1.SelectedValue.ToString());
            //var sql = from m in obj
            //          where m.StudentID == a
            //          select m;

            //var sql = from m in obj
            //          where m.Sname== cmb1.SelectedValue.ToString()
            //          select m;

            int a = int.Parse(cmb1.SelectedValue.ToString());
            var sql = from m in obj
                      where m.Marks == a
                      select m;




            dg1.ItemsSource = sql.ToList();
        }

        private void cmb1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
