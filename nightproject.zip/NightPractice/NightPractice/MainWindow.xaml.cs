﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace NightPractice
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            VaibhavInfoEntities vb = new VaibhavInfoEntities();

            StudentInfo SI = new StudentInfo();

            DbSet < StudentInfo> obj = vb.StudentInfoes;
            //int a = Convert.ToInt32(SCombo.SelectedValue.ToString());
            //var sql = from m in obj
            //          where m.StudentID == a
            //          select m;

            //var sql = from m in obj
            //          where m.Sname == SCombo.SelectedValue.ToString()
            //          select m;
            int b = Convert.ToInt32(SCombo.SelectedValue.ToString());
            var sql = from m in obj
                      where m.Marks == b
                      select m;

            SGrid.ItemsSource = sql.ToList();
            vb.SaveChanges();
            MessageBox.Show("Thanos");




        }

        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void SCombo_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            VaibhavInfoEntities vb = new VaibhavInfoEntities();

            StudentInfo SI = new StudentInfo();

            DbSet<StudentInfo> obj = vb.StudentInfoes;

            //var sql = from m in obj
            //          select m.StudentID;

            //var sql = (from m in obj

            //          select  m.Sname).Distinct() ;

            var sql = (from m in obj
                       select m.Marks).Distinct();

            foreach (var itm in sql)
            {
                SCombo.Items.Add(itm);
            }
        }
    }
}
