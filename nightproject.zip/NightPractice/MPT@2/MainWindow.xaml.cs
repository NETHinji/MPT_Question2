﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MPT_2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            VaibhavInfoEntities vb = new VaibhavInfoEntities();

            StudentInfo sf = new StudentInfo();

            DbSet<StudentInfo> obj = vb.StudentInfoes;

            //var sql = from m in obj
            //          select m.StudentID;

            //var sql = (from m in obj
            //           select m.Sname);

            

            foreach (var sql in (from m in obj
                                     select m.Marks).Distinct())
            {
                cmb1.Items.Add(sql);
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            VaibhavInfoEntities vb = new VaibhavInfoEntities();

            StudentInfo sf = new StudentInfo();

            DbSet<StudentInfo> obj = vb.StudentInfoes;
            //int a = int.Parse(cmb1.SelectedValue.ToString());
            //var sql = from m in obj
            //          where m.StudentID == a
            //          select m;

            //var sql = from m in obj
            //          where m.Sname == cmb1.SelectedValue.ToString()
            //          select m;

            int a = int.Parse(cmb1.SelectedValue.ToString());
            var sql = from m in obj
                      where m.Marks == a
                      select m;




            DataGrid1.ItemsSource = sql.ToList();
        }
    }
}
